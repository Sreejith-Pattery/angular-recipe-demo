import { Component, OnInit } from '@angular/core';
import * as Firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  ngOnInit(): void {  
    Firebase.initializeApp({
      apiKey: "AIzaSyAGAA2ZasQnNoR68-E9-G9owHr5qqZjUcU",
      authDomain: "cordovapushdemo-b4699.firebaseapp.com",
    });
  }
  title = 'app';
  loadedFeature = 'recipe';

  onNavigate(feature:string){
    this.loadedFeature = feature;
  }
}
